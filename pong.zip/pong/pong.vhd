library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity pong is
end pong;

architecture Behavioral of pong is

begin


end Behavioral;

